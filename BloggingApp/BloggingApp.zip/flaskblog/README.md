Just press the run.py file to run
